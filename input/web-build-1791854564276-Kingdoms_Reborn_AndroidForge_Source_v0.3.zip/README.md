# Kingdoms Reborn Android Project v0.3

Native Android Gradle project wrapping the Kingdoms Reborn single-player game in WebView.

## Game features
- Custom maxed start: Castle 37, Prestige 37, prototype buildings level 37
- Huge army and abundant resources
- Six territory locations with local simulated marches, attacks, rewards and territory control
- Dragon ability, hero ability, constellation blessing and civilization selection
- Local saves on the device

## Build with AndroidForge
1. Upload this ZIP to https://professional-x.github.io/AndroidForge/
2. Choose `auto` or `debug` and start the build.
3. Download the `AndroidForge-APKs` artifact ZIP when the workflow completes, then extract and install the APK.

AndroidForge repository: https://github.com/Administrator1457/AndroidForge

## Notes
This is a custom single-player prototype. Prestige 37 is a custom setting, not a verified official Clash of Kings cap. Territory battles are simulated locally, not online PvP. No proprietary original-game code or assets are included.
