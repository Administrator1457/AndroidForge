plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.streetlegends"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.streetlegends"
        minSdk = 26
        targetSdk = 34
        versionCode = 34
        versionName = "3.4.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlinOptions {
    jvmTarget = "17"
}
