# Kingdoms Reborn Android Project v0.4

Native Android Gradle project wrapping the Kingdoms Reborn single-player game in WebView.

## Game features
- Custom maxed start: Castle 37, Prestige 37, prototype buildings level 37
- Huge army and abundant resources
- Six territory locations with local simulated marches, attacks, rewards and territory control
- Dragon ability, hero ability, constellation blessing and civilization selection
- Local saves on the device

## Identity check before installing
- App label in `app/src/main/AndroidManifest.xml`: `Kingdoms Reborn`
- Android application ID in `app/build.gradle`: `com.kingdomsreborn.game`
- Launcher activity: `com.kingdomsreborn.game.MainActivity`

Only install an APK if its app label is Kingdoms Reborn and its package/application ID is `com.kingdomsreborn.game`. The earlier APK from the AndroidForge run was not verified and should not be used.

## Build with AndroidForge
1. Upload this ZIP to https://professional-x.github.io/AndroidForge/
2. Choose `auto` or `debug` and start the build.
3. Download the `AndroidForge-APKs` artifact ZIP when the workflow completes, then extract and install the APK.

AndroidForge repository: https://github.com/Administrator1457/AndroidForge

## Notes
This is a custom single-player prototype. Prestige 37 is a custom setting, not a verified official Clash of Kings cap. Territory battles are simulated locally, not online PvP. No proprietary original-game code or assets are included.
