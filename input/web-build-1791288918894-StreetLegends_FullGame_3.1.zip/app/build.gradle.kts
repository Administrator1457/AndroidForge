
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.streetlegends"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.streetlegends"
        minSdk = 26
        targetSdk = 35
        versionCode = 30
        versionName = "3.0.0"
    }
}
