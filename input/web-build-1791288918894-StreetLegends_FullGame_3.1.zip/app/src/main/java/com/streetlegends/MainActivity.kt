package com.streetlegends

import android.app.*
import android.os.*
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.*
import android.widget.*
import android.content.*
import kotlin.math.*
import kotlin.random.Random

data class Car(
    val id:Int, val name:String, val tier:Int, val price:Int, var hp:Int, var grip:Int,
    var weight:Int, var owned:Boolean=false, var paint:Int=0, var wheels:Int=0, var stance:Int=0,
    var engine:Int=0, var turbo:Int=0, var ecu:Int=0, var gearbox:Int=0, var tyres:Int=0, var exhaust:Int=0
) {
    fun drivetrain():String = when(id) {
        2,6,8,10,15,17,19 -> "AWD"
        5,12 -> "FWD"
        else -> "RWD"
    }
    fun engineType():String = when(id) {
        0,1,12,13 -> "I4"
        2,5,6,8,10,15,17,19 -> "V6"
        else -> "V8"
    }
    fun displacement():Double = when(engineType()) {
        "I4" -> 2.0
        "V6" -> 3.8
        else -> 5.0
    }
    fun torque():Int = (power()*0.72 + when(engineType()){"I4"->25;"V6"->55;else->95}).toInt()
    fun gearRatios():DoubleArray = when(tier) {
        1 -> doubleArrayOf(3.45,2.10,1.48,1.16,0.93,0.76)
        2 -> doubleArrayOf(3.20,2.05,1.46,1.15,0.91,0.74)
        3 -> doubleArrayOf(3.05,1.98,1.42,1.12,0.89,0.72)
        4 -> doubleArrayOf(2.90,1.92,1.39,1.10,0.86,0.69)
        else -> doubleArrayOf(2.75,1.88,1.36,1.07,0.84,0.67)
    }
    fun redline():Int = when(tier){1->6500;2->6800;3->7000;4->7200;else->7600}
    fun power():Int = hp + engine*35 + turbo*55 + ecu*30 + exhaust*20
    fun handling():Int = min(100, grip + tyres*4 + gearbox*2)
    fun perf():Int = power()*1000/max(900, weight) + handling()*3
}


class RaceView(
    context: Context,
    private val street: Boolean,
    private val carName: String,
    private val onShift: () -> Unit,
    private val onNitro: () -> Unit,
    private val onQuit: () -> Unit
) : View(context) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var player=0f
    private var rival=0f
    private var rpm=3400
    private var gear=1
    private var nitroReady=true
    private var damage=0
    private var countdown=3
    private var tick=0
    private var flash=""
    private var running=true

    init { setBackgroundColor(Color.rgb(10,10,12)) }

    fun update(progress:Float, opp:Float, rpmNow:Int, gearNow:Int, nitro:Boolean, dmg:Int, msg:String) {
        player=progress; rival=opp; rpm=rpmNow; gear=gearNow; nitroReady=nitro; damage=dmg; flash=msg
        invalidate()
    }
    fun stop(){running=false}

    override fun onDraw(c:Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        // sky
        p.color=Color.rgb(22,25,35); c.drawRect(0f,0f,w,h*.42f,p)
        // city silhouettes
        p.color=Color.rgb(15,15,19)
        for(i in 0..10) {
            val bw=w/11f; val bh=(40+(i*17%120)).toFloat()
            c.drawRect(i*bw,h*.42f-bh,(i+1)*bw-3,h*.42f,p)
        }
        // road
        p.color=Color.rgb(42,42,45); c.drawRect(0f,h*.42f,w,h,p)
        p.color=Color.rgb(185,185,185)
        c.drawRect(w*.49f, h*.42f, w*.51f,h,p)
        // lane marks
        p.color=Color.WHITE
        for(i in 0..8) {
            val y=h*.45f+i*h*.07f
            c.drawRect(w*.485f,y,w*.515f,y+28,p)
        }
        // HUD
        p.typeface=Typeface.DEFAULT_BOLD
        p.textSize=22f; p.color=Color.WHITE
        c.drawText("STREET LEGENDS",20f,36f,p)
        p.textSize=14f
        c.drawText(carName,20f,60f,p)
        c.drawText(if(street)"STREET / HEAT" else "DRAG / 6-SPEED",20f,82f,p)
        // progress bars
        p.color=Color.DKGRAY; c.drawRoundRect(RectF(20f,95f,w-20f,110f),8f,8f,p)
        p.color=Color.WHITE; c.drawRoundRect(RectF(20f,95f,20f+(w-40f)*(player/100f),110f),8f,8f,p)
        p.color=Color.GRAY; c.drawRoundRect(RectF(20f,118f,w-20f,130f),8f,8f,p)
        p.color=Color.LTGRAY; c.drawRoundRect(RectF(20f,118f,20f+(w-40f)*(rival/100f),130f),8f,8f,p)

        // Cars
        drawCar(c,w*.50f,h*.78f,1.0f,Color.rgb(210,45,35),damage)
        val rivalX=w*.50f + (rival-player)*2.2f
        drawCar(c,rivalX.coerceIn(w*.18f,w*.82f),h*.64f,.72f,Color.rgb(45,90,190),0)

        // RPM tachometer
        p.style=Paint.Style.STROKE; p.strokeWidth=7f; p.color=Color.WHITE
        c.drawCircle(w*.18f,h*.87f,48f,p)
        p.style=Paint.Style.FILL; p.textSize=16f
        c.drawText("$rpm RPM",w*.18f-35f,h*.87f+5f,p)
        c.drawText("GEAR $gear",w*.18f-34f,h*.87f+28f,p)
        p.textSize=14f
        c.drawText("NITRO ${if(nitroReady)"READY" else "USED"}",w*.64f,h*.87f,p)
        c.drawText("DMG $damage%",w*.64f,h*.87f+22f,p)

        if(flash.isNotEmpty()){
            p.textSize=23f; p.color=Color.WHITE
            val tw=p.measureText(flash)
            c.drawText(flash,(w-tw)/2f,h*.20f,p)
        }

        // touch hints
        p.textSize=13f
        c.drawText("TAP LEFT = SHIFT",20f,h-18f,p)
        c.drawText("TAP RIGHT = NITRO",w-145f,h-18f,p)
    }

    private fun drawCar(c:Canvas,x:Float,y:Float,scale:Float,col:Int,dmg:Int) {
        p.color=Color.BLACK
        c.drawOval(RectF(x-65*scale,y-20*scale,x+65*scale,y+55*scale),p)
        p.color=col
        c.drawRoundRect(RectF(x-52*scale,y-40*scale,x+52*scale,y+35*scale),18*scale,18*scale,p)
        p.color=Color.rgb(35,35,40)
        c.drawRoundRect(RectF(x-30*scale,y-32*scale,x+30*scale,y-5*scale),8*scale,8*scale,p)
        p.color=Color.rgb(230,230,230)
        c.drawRect(x-46*scale,y-5*scale,x-35*scale,y+8*scale,p)
        c.drawRect(x+35*scale,y-5*scale,x+46*scale,y+8*scale,p)
        p.color=Color.BLACK
        c.drawCircle(x-38*scale,y+35*scale,13*scale,p)
        c.drawCircle(x+38*scale,y+35*scale,13*scale,p)
        if(dmg>0){
            p.color=Color.WHITE; p.strokeWidth=3f
            c.drawLine(x-20*scale,y-20*scale,x+5*scale,y+8*scale,p)
            c.drawLine(x+10*scale,y-12*scale,x+32*scale,y+15*scale,p)
        }
    }

    override fun onTouchEvent(e:android.view.MotionEvent):Boolean {
        if(e.action==MotionEvent.ACTION_UP){
            if(e.y>height*.80f){
                if(e.x<width/2) onShift() else onNitro()
            }
            return true
        }
        return true
    }
}

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private val prefs by lazy { getSharedPreferences("save", MODE_PRIVATE) }
    private var cash = 100000
    private var rep = 0
    private var selected = 0
    private var mode = "GARAGE"
    private var raceCar = 0
    private var raceProgress = 0.0
    private var opponent = 0.0
    private var rpm = 3400
    private var gear = 1
    private var nitro = 1.0
    private var racing = false
    private var perfects = 0
    private var damage = 0
    private var wins = 0
    private var losses = 0
    private var fuel = 100
    private var eventUnlocked = 1
    private var raceDistance = 100
    private var traction = 0.0
    private var heat = 0
    private var launch = 0
    private var tyreTemp = 25.0
    private var wheelspin = 0.0
    private var finalDrive = 3.40
    private var boostPsi = 14.0
    private var tyrePressure = 28.0
    private var suspension = 50.0
    private var launchRPM = 4200
    private var tractionControl = true
    private var testMode = false
    private var raceView:RaceView? = null

    private val cars = mutableListOf(
        Car(0,"VX Street Fighter",1,0,230,65,1550,true),
        Car(1,"Night Runner",2,6500,285,72,1480),
        Car(2,"Apex GT",2,15000,360,78,1420),
        Car(3,"Redline SS",3,26000,410,70,1510),
        Car(4,"Thunder V8",3,40000,480,74,1600),
        Car(5,"Neon R",3,52000,445,86,1340),
        Car(6,"Blackout XR",4,72000,570,82,1460),
        Car(7,"Inferno RS",4,90000,640,79,1390),
        Car(8,"Apex R",4,120000,710,88,1310),
        Car(9,"Kingpin",5,175000,820,84,1420),
        Car(10,"Nightmare",5,225000,910,91,1280),
        Car(11,"Street Titan",5,275000,1020,87,1500),
        Car(12,"Pulse GT",2,19000,330,82,1370),
        Car(13,"Riot 6",3,43000,390,89,1290),
        Car(14,"Vandal",3,61000,515,77,1410),
        Car(15,"Overdrive",4,105000,680,90,1300),
        Car(16,"Red Comet",4,132000,760,86,1270),
        Car(17,"Phantom X",5,210000,880,94,1240),
        Car(18,"Hellcat Alley",5,295000,1100,80,1550),
        Car(19,"Legend One",5,450000,1250,96,1190)
    )

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        load()
        showGarage()
    }

    private fun save() {
        val e=prefs.edit().putInt("cash",cash).putInt("rep",rep).putInt("selected",selected).putInt("damage",damage).putInt("wins",wins)
            .putInt("losses",losses).putInt("fuel",fuel).putInt("eventUnlocked",eventUnlocked)
            .putInt("partsTokens",partsTokens).putInt("partsRank",partsRank).putInt("crewRep",crewRep)
            .putInt("rivalIndex",rivalIndex).putInt("champPoints",championshipPoints).putInt("champRound",championshipRound)
            .putInt("bossWins",bossWins).putInt("totalRaces",totalRaces).putInt("totalCashEarned",totalCashEarned)
            .putInt("perfectShiftTotal",perfectShiftTotal).putInt("nitroUses",nitroUses).putBoolean("dailyClaimed",dailyClaimed).putString("dailyDay",if(dailyClaimed)java.text.SimpleDateFormat("yyyyMMdd").format(java.util.Date()) else "")
        cars.forEach { c ->
            e.putBoolean("own${c.id}",c.owned)
            e.putInt("eng${c.id}",c.engine).putInt("tur${c.id}",c.turbo).putInt("ecu${c.id}",c.ecu)
                .putInt("gb${c.id}",c.gearbox).putInt("ty${c.id}",c.tyres).putInt("ex${c.id}",c.exhaust)
                .putInt("paint${c.id}",c.paint).putInt("wheel${c.id}",c.wheels).putInt("stance${c.id}",c.stance)
        }
        e.apply()
    }

    private fun load() {
        cash=prefs.getInt("cash",100000); rep=prefs.getInt("rep",0); selected=prefs.getInt("selected",0); damage=prefs.getInt("damage",0); wins=prefs.getInt("wins",0)
        losses=prefs.getInt("losses",0); fuel=prefs.getInt("fuel",100); eventUnlocked=prefs.getInt("eventUnlocked",1)
        partsTokens=prefs.getInt("partsTokens",12); partsRank=prefs.getInt("partsRank",1); crewRep=prefs.getInt("crewRep",0)
        rivalIndex=prefs.getInt("rivalIndex",0); championshipPoints=prefs.getInt("champPoints",0); championshipRound=prefs.getInt("champRound",0)
        bossWins=prefs.getInt("bossWins",0); totalRaces=prefs.getInt("totalRaces",0); totalCashEarned=prefs.getInt("totalCashEarned",0)
        perfectShiftTotal=prefs.getInt("perfectShiftTotal",0); nitroUses=prefs.getInt("nitroUses",0); dailyClaimed=prefs.getBoolean("dailyClaimed",false)
        cars.forEach { c ->
            c.owned=prefs.getBoolean("own${c.id}",c.owned)
            c.engine=prefs.getInt("eng${c.id}",0); c.turbo=prefs.getInt("tur${c.id}",0)
            c.ecu=prefs.getInt("ecu${c.id}",0); c.gearbox=prefs.getInt("gb${c.id}",0)
            c.tyres=prefs.getInt("ty${c.id}",0); c.exhaust=prefs.getInt("ex${c.id}",0)
            c.paint=prefs.getInt("paint${c.id}",0); c.wheels=prefs.getInt("wheel${c.id}",0); c.stance=prefs.getInt("stance${c.id}",0)
        }
    }

    private fun base():LinearLayout {
        box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(18,16,18,20)
        box.setBackgroundColor(Color.rgb(12,12,14))
        scroll=ScrollView(this); scroll.addView(box); setContentView(scroll)
        return box
    }
    private fun title(s:String){ text(s,24,true) }
    private fun text(s:String,size:Int=16,bold:Boolean=false) {
        val t=TextView(this); t.text=s; t.textSize=size.toFloat(); t.setTextColor(Color.WHITE)
        t.setPadding(6,8,6,8); if(bold)t.setTypeface(null,1); box.addView(t)
    }
    private fun button(s:String, action:()->Unit) {
        val b=Button(this); b.text=s; b.setTextColor(Color.WHITE); b.setOnClickListener{action()}
        b.setBackgroundColor(Color.rgb(38,38,42)); box.addView(b)
    }
    private fun line(){ val v=View(this); v.layoutParams=LinearLayout.LayoutParams(-1,2); v.setBackgroundColor(Color.rgb(60,60,65)); box.addView(v) }
    private fun money(n:Int)="$"+String.format("%,d",n)

    private fun header() {
        title("STREET LEGENDS")
        text("${money(cash)}   •   REP $rep   •   Parts $partsTokens   •   W $wins / L $losses",15,true)
        text("Crew REP $crewRep   •   Bosses $bossWins   •   Cars ${cars.count{it.owned}}/${cars.size}",13)
        line()
    }

    private fun showGarage() {
        mode="GARAGE"; base(); header()
        val c=cars[selected]
        text("CURRENT RIDE",13,true)
        text("${c.name}   |   T${c.tier}",23,true)
        text("${c.power()} HP   •   Grip ${c.handling()}   •   ${c.weight} kg   •   ${c.drivetrain()}   •   ${c.redline()} RPM",15)
        text("0–100 estimate ${estimate0100(c)}s   •   1/4 mile ${estimateQuarter(c)}s",14)
        button("🏁 DRAG RACE") { startDrag() }
        button("🔥 STREET RACE / BURNOUT MODE") { startStreet() }
        button("🔧 UPGRADES") { showUpgrades() }
        button("🎨 CUSTOMISE") { showCustom() }
        button("🚗 DEALERSHIP / CAR COLLECTION") { showDealer() }
        button("🏆 CAREER + BOSSES") { showCareer() }
        button("🏅 CHAMPIONSHIP") { showChampionship() }
        button("👊 CREW + RIVALS") { showCrew() }
        button("🧩 PARTS + LOOT") { showParts() }
        button("🎯 DAILY CHALLENGES") { showDaily() }
        button("🏅 PROFILE + ACHIEVEMENTS") { showProfile() }
        button("📊 DYNO / TUNING") { showDyno() }
        button("🛠 REPAIR + FUEL") { showService() }
        button("💾 SAVE GAME") { save(); Toast.makeText(this,"Game saved",Toast.LENGTH_SHORT).show() }
        button("⚙ DEVELOPER MENU") { showDev() }
        line(); text("GARAGE",18,true)
        cars.filter{it.owned}.forEach { car ->
            button(if(car.id==selected) "▶ ${car.name}  [T${car.tier}]" else "${car.name}  [T${car.tier}]") { selected=car.id; save(); showGarage() }
        }
    }

    private fun showDealer() {
        base(); header(); title("DEALERSHIP")
        cars.forEach { c ->
            val status=if(c.owned)"OWNED" else money(c.price)
            button("${c.name} • T${c.tier} • ${c.power()} HP • $status") {
                if(!c.owned && cash>=c.price){ cash-=c.price;c.owned=true;selected=c.id;save();showDealer();Toast.makeText(this,"Purchased ${c.name}",Toast.LENGTH_SHORT).show() }
                else if(!c.owned) Toast.makeText(this,"Not enough cash",Toast.LENGTH_SHORT).show()
                else {selected=c.id;showGarage()}
            }
        }
        button("← BACK") {showGarage()}
    }

    private fun showUpgrades() {
        base(); header(); val c=cars[selected]; title("UPGRADES — ${c.name}")
        val parts=listOf(
            Triple("Engine",c.engine,1800){c.engine},
            Triple("Turbo",c.turbo,2600){c.turbo},
            Triple("ECU",c.ecu,2200){c.ecu},
            Triple("Gearbox",c.gearbox,2400){c.gearbox},
            Triple("Tyres",c.tyres,1700){c.tyres},
            Triple("Exhaust",c.exhaust,1500){c.exhaust}
        )
        parts.forEachIndexed { i,p ->
            val lv=p.second
            val cost=p.third*(lv+1)
            button("${p.first} • Stage $lv/5 • ${money(cost)}") {
                if(lv<5 && cash>=cost) {
                    cash-=cost
                    when(i){0->c.engine++;1->c.turbo++;2->c.ecu++;3->c.gearbox++;4->c.tyres++;5->c.exhaust++}
                    save();showUpgrades()
                } else Toast.makeText(this,"Need more cash or maxed",Toast.LENGTH_SHORT).show()
            }
        }
        line(); text("Power ${c.power()} HP | Handling ${c.handling()} | Perf ${c.perf()}",17,true)
        button("← BACK") {showGarage()}
    }

    private fun showCustom() {
        base(); header(); val c=cars[selected]; title("CUSTOMISE — ${c.name}")
        val paints=listOf("Factory","Red","Blue","Black","White","Purple","Green","Gold")
        paints.forEachIndexed{i,n->button("Paint: $n ${if(c.paint==i)"✓" else ""}"){c.paint=i;save();showCustom()}}
        button("Wheels: ${c.wheels+1}/6") {c.wheels=(c.wheels+1)%6;save();showCustom()}
        button("Stance: ${c.stance+1}/4") {c.stance=(c.stance+1)%4;save();showCustom()}
        button("🔥 STREET PACKAGE") { c.wheels=(c.wheels+2)%6; c.stance=3; c.paint=(c.paint+3)%8; save(); showCustom() }
        button("BUILD PREVIEW") { Toast.makeText(this,"${c.name} • ${c.paint+1}/8 paint • wheels ${c.wheels+1}/6 • stance ${c.stance+1}/4",Toast.LENGTH_LONG).show() }
        button("← BACK") {showGarage()}
    }


    private fun showDyno() {
        base(); header()
        val c=cars[selected]
        title("DYNO / TEST & TUNE")
        text("${c.name} • ${c.engineType()} ${"%.1f".format(c.displacement())}L • ${c.drivetrain()}",16,true)
        text("${c.power()} HP • ${c.torque()} Nm • ${c.redline()} RPM • TC ${if(tractionControl)"ON" else "OFF"}",15)
        text("BASE POWER: ${c.hp} HP   •   BUILT: ${c.power()} HP",15)
        text("HANDLING: ${c.handling()} / 100   •   WEIGHT: ${c.weight} kg",15)
        text("EST 0–100: ${estimate0100(c)}s   •   EST 1/4: ${estimateQuarter(c)}s",16,true)
        line()
        text("FINAL DRIVE: ${"%.2f".format(finalDrive)}",15)
        button("Final Drive − 0.10") {finalDrive=max(2.40,finalDrive-0.10);showDyno()}
        button("Final Drive + 0.10") {finalDrive=min(5.20,finalDrive+0.10);showDyno()}
        text("BOOST: ${"%.1f".format(boostPsi)} PSI",15)
        button("Boost − 1 PSI") {boostPsi=max(5.0,boostPsi-1);showDyno()}
        button("Boost + 1 PSI") {boostPsi=min(30.0,boostPsi+1);showDyno()}
        text("TYRE PRESSURE: ${"%.1f".format(tyrePressure)} PSI",15)
        button("Tyres − 1 PSI (more launch grip)") {tyrePressure=max(18.0,tyrePressure-1);showDyno()}
        button("Tyres + 1 PSI (less rolling resistance)") {tyrePressure=min(42.0,tyrePressure+1);showDyno()}
        text("SUSPENSION: ${suspension.toInt()} / 100",15)
        button("Suspension − 5") {suspension=max(0.0,suspension-5);showDyno()}
        button("Suspension + 5") {suspension=min(100.0,suspension+5);showDyno()}
        text("LAUNCH RPM: $launchRPM",15)
        button("Launch RPM − 200") {launchRPM=max(3000,launchRPM-200);showDyno()}
        button("Launch RPM + 200") {launchRPM=min(7000,launchRPM+200);showDyno()}
        button("TRACTION CONTROL: ${if(tractionControl)"ON" else "OFF"}") {
            tractionControl=!tractionControl; showDyno()
        }
        button("RUN TEST & TUNE") {
            testMode=true
            raceScreen(false, false)
        }
        button("RESET TUNE") {
            finalDrive=3.40; boostPsi=14.0; tyrePressure=28.0; suspension=50.0; launchRPM=4200; showDyno()
        }
        line()
        button("LIGHTEN CAR (-40 kg) • $4,000") {
            if(cash>=4000 && c.weight>1050){cash-=4000;c.weight-=40;save();showDyno()}
        }
        button("RESET DAMAGE (FREE DEV TEST)") {damage=0;save();showDyno()}
        button("← BACK"){showGarage()}
    }

    private fun estimate0100(c:Car):String {
        val p=c.power().toDouble()
        val grip=c.handling().toDouble()
        val drive=when(c.drivetrain()){"AWD"->0.92;"RWD"->1.00;else->1.07}
        val tune=(1.0 - ((boostPsi-14.0)*0.004)).coerceIn(0.88,1.08)
        val t=(11.8*drive*sqrt(c.weight/1500.0)/(sqrt(max(180.0,p)/230.0)))*(1.12-grip/1000.0)*tune
        return "%.2f".format(t.coerceIn(2.1,12.0))
    }

    private fun estimateQuarter(c:Car):String {
        val p=c.power().toDouble()
        val grip=c.handling().toDouble()
        val drive=when(c.drivetrain()){"AWD"->0.96;"RWD"->1.02;else->1.06}
        val t=(13.9*drive*sqrt(c.weight/1500.0)/(p/230.0).pow(1.0/3.0))*(1.10-grip/1200.0)
        return "%.2f".format(t.coerceIn(7.0,20.0))
    }

    private fun showParts() {
        base(); header(); title("PARTS + LOOT")
        val names=listOf("Forged Engine","Big Turbo","Race ECU","Close-Ratio Gearbox","Drag Radials","Race Exhaust","Weight Reduction Kit")
        text("PARTS RANK $partsRank   •   TOKENS $partsTokens",16,true)
        text("Tokens buy random performance parts. Higher rank improves drop quality.",14)
        button("OPEN PARTS CRATE • 3 TOKENS") {
            if(partsTokens>=3){
                partsTokens-=3
                val gain=Random.nextInt(1,5)
                val part=names.random()
                if(gain>=3) partsRank=min(10,partsRank+1)
                Toast.makeText(this,"📦 $part x$gain  • Rank $partsRank",Toast.LENGTH_LONG).show();save();showParts()
            } else Toast.makeText(this,"Need 3 parts tokens",Toast.LENGTH_SHORT).show()
        }
        button("BUY 1 TOKEN • $2,500") {
            if(cash>=2500){cash-=2500;partsTokens++;save();showParts()} else Toast.makeText(this,"Not enough cash",Toast.LENGTH_SHORT).show()
        }
        names.forEach { n -> text("• $n — available through crates",14) }
        button("← BACK"){showGarage()}
    }

    private fun showDaily() {
        base(); header(); title("DAILY CHALLENGES")
        val done=dailyClaimed
        text(if(done)"TODAY'S REWARD CLAIMED ✓" else "Complete the challenge and claim the reward.",15,true)
        val challenge=when((wins+totalRaces)%5){0->"Win 2 races";1->"Land 3 perfect shifts";2->"Use nitro once";3->"Finish a street race without quitting";else->"Win 3 races"}
        text("TODAY: $challenge",20,true)
        button(if(done)"CLAIMED" else "CLAIM DAILY REWARD • $4,000 + 2 TOKENS") {
            if(!done){
                cash+=4000; partsTokens+=2; rep+=25; dailyClaimed=true; totalCashEarned+=4000; prefs.edit().putString("dailyDay",java.text.SimpleDateFormat("yyyyMMdd").format(java.util.Date())).apply(); save();showDaily()
            }
        }
        button("← BACK"){showGarage()}
    }

    private fun showProfile() {
        base(); header(); title("PROFILE + ACHIEVEMENTS")
        text("RACES $totalRaces   •   WINS $wins   •   LOSSES $losses",16,true)
        text("Perfect shifts $perfectShiftTotal   •   Nitro uses $nitroUses",15)
        text("Lifetime cash earned ${money(totalCashEarned)}   •   Parts Rank $partsRank",15)
        val ach=listOf(
            "FIRST BLOOD" to (totalRaces>=1), "STREAK RUNNER" to (wins>=5),
            "SHIFT KING" to (perfectShiftTotal>=25), "NITRO JUNKIE" to (nitroUses>=10),
            "CAR COLLECTOR" to (cars.count{it.owned}>=10), "MILLIONAIRE" to (totalCashEarned>=1000000),
            "BOSS BREAKER" to (bossWins>=3), "CHAMPION" to (championshipPoints>=40)
        )
        ach.forEach{(n,ok)->text("${if(ok)"🏆" else "🔒"} $n",15)}
        button("← BACK"){showGarage()}
    }

    private fun showCrew() {
        base(); header(); title("CREW + RIVALS")
        val rivals=listOf("Razor","Viper","Torque","Ghost","Reaper","King")
        val rival=rivals[rivalIndex.coerceIn(0,rivals.lastIndex)]
        text("YOUR CREW REP: $crewRep",18,true)
        text("CURRENT RIVAL: $rival",16,true)
        text("Beat rivals to climb the street ladder and unlock stronger opponents.",14)
        button("RIVAL DUEL • $rival") { raceEventIndex=90+rivalIndex; startStreet(false) }
        button("CREW RUN • +REP") { raceEventIndex=80; startStreet(false) }
        button("PROMOTE CREW") {
            if(crewRep>=100){crewRep-=100;rep+=50;cash+=10000;Toast.makeText(this,"Crew promotion! +$10,000",Toast.LENGTH_SHORT).show();save();showCrew()}
            else Toast.makeText(this,"Need 100 crew REP",Toast.LENGTH_SHORT).show()
        }
        button("← BACK"){showGarage()}
    }

    private fun showChampionship() {
        base(); header(); title("CHAMPIONSHIP")
        val rounds=listOf("Industrial","Harbour","Downtown","Desert","Mountain")
        text("ROUND ${championshipRound+1}/5   •   POINTS $championshipPoints",18,true)
        text("Win rounds for points. Complete all five for the championship prize.",14)
        if(championshipRound<5){
            button("RACE ${rounds[championshipRound]} ROUND") {raceEventIndex=70+championshipRound;startDrag(false)}
        } else {
            text("🏆 CHAMPIONSHIP COMPLETE!",22,true)
            button("CLAIM $100,000 CHAMPIONSHIP PRIZE") {cash+=100000;totalCashEarned+=100000;championshipRound=6;save();showChampionship()}
        }
        button("RESET CHAMPIONSHIP (TEST)"){championshipRound=0;championshipPoints=0;save();showChampionship()}
        button("← BACK"){showGarage()}
    }

    private fun showService() {
        base(); header()
        title("SERVICE BAY")
        text("Damage: $damage%   •   Fuel: $fuel%",16,true)
        button("REPAIR TO 100% • $${damage*35}") {
            val cost=damage*35
            if(cash>=cost){cash-=cost;damage=0;save();showService()}
            else Toast.makeText(this,"Not enough cash",Toast.LENGTH_SHORT).show()
        }
        button("REFUEL TO 100% • $1,000") {
            if(cash>=1000){cash-=1000;fuel=100;save();showService()}
        }
        button("← BACK"){showGarage()}
    }

    private fun showCareer() {
        base(); header(); title("CAREER")
        val races=listOf(
            "01 — Industrial Sprint • T1 • +$2,000",
            "02 — Harbour Run • T2 • +$3,500",
            "03 — Night District • T2 • +$5,000",
            "04 — Westside Boss • T3 • +$8,000",
            "05 — Tunnel Kings • T3 • +$12,000",
            "06 — Highway Heat • T4 • +$18,000",
            "07 — Downtown Boss • T4 • +$28,000",
            "08 — Redline War • T5 • +$40,000",
            "09 — Final Boss • T5 • +$75,000"
        )
        races.forEachIndexed{i,s->
            val unlocked=i < eventUnlocked
            button("${if(unlocked)"🔓" else "🔒"} $s") {
                if(unlocked) { raceCar=selected; raceEventIndex=i; if(i%2==0)startDrag(true) else startStreet(true) }
                else Toast.makeText(this,"Win the previous event first",Toast.LENGTH_SHORT).show()
            }
        }
        button("← BACK"){showGarage()}
    }

    private fun showDev() {
        base(); header(); title("DEVELOPER MENU")
        text("Private testing tools for Street Legends.",14)
        button("+ $100,000") {cash+=100000;save();showDev()}
        button("UNLOCK ALL CARS") {cars.forEach{it.owned=true};save();showDev()}
        button("MAX CURRENT CAR") {val c=cars[selected];c.engine=5;c.turbo=5;c.ecu=5;c.gearbox=5;c.tyres=5;c.exhaust=5;save();showDev()}
        button("MAX EVERYTHING") {cars.forEach{it.owned=true;it.engine=5;it.turbo=5;it.ecu=5;it.gearbox=5;it.tyres=5;it.exhaust=5};cash+=1000000;save();showDev()}
        button("← BACK"){showGarage()}
    }

    private fun raceScreen(street:Boolean, career:Boolean=false) {
        if(fuel < 10) { Toast.makeText(this,"Not enough fuel — visit Service Bay",Toast.LENGTH_SHORT).show(); return }
        fuel -= 10
        totalRaces++
        mode=if(street)"STREET" else "DRAG"; racing=true; raceCar=selected
        val c=cars[raceCar]
        raceProgress=0.0; opponent=0.0; rpm=launchRPM; gear=1; nitro=1.0
        perfects=0; launch=0; traction=0.0; tyreTemp=25.0; wheelspin=0.0
        val rv=RaceView(this,street,c.name,
            { if(racing) shiftVisual() },
            { if(racing && nitro>0){
                nitro=0.0
                nitroUses++
                val nitroGain=if(c.drivetrain()=="AWD")9.0 else 7.0
                raceProgress+=nitroGain
                tyreTemp=min(120.0,tyreTemp+8)
            }},
            { racing=false; showGarage() })
        raceView=rv
        setContentView(rv)

        val h=Handler(Looper.getMainLooper())
        var lastShiftTick=0
        val loop=object:Runnable{
            override fun run(){
                if(!racing)return

                val redline=c.redline()
                val ratios=c.gearRatios()
                val currentRatio=ratios[(gear-1).coerceIn(0,5)]
                val target=when(gear){
                    1->min(redline-350,launchRPM+900)
                    2->redline-500
                    3->redline-450
                    4->redline-400
                    5->redline-350
                    else->redline-300
                }

                val powerFactor=(c.power()/230.0).coerceAtLeast(1.0)
                val gearFactor=(1.0 + (gear-1)*0.035)
                val tempGripPenalty=when {
                    tyreTemp<35 -> 0.10
                    tyreTemp>95 -> 0.18
                    else -> 0.0
                }
                val pressurePenalty=abs(tyrePressure-27.0)*0.006
                val driveLaunch=when(c.drivetrain()) {
                    "AWD" -> 1.16
                    "RWD" -> 1.02
                    else -> 0.96
                }
                val suspensionFactor=1.0 + (50.0-suspension)*0.001
                val tuneFactor=(1.0 + (boostPsi-14.0)*0.004).coerceIn(0.94,1.08)
                val damageFactor=(1.0-damage/260.0).coerceAtLeast(0.55)

                if(gear==1 && launch==0){
                    val launchError=abs(rpm-launchRPM)
                    val rawSpin=((launchError/1600.0) + when(c.drivetrain()){"RWD"->0.16;"FWD"->0.11;else->0.04})
                        .coerceIn(0.0,0.85)
                    wheelspin=if(tractionControl) (rawSpin*0.58).coerceAtMost(0.55) else rawSpin
                    traction=(1.0-wheelspin).coerceIn(if(tractionControl)0.42 else 0.20,1.0)
                    launch=1
                    statusMessage(rv,"LAUNCH • ${c.drivetrain()} • ${if(wheelspin<0.22)"HOOKED" else "WHEELSPIN"}")
                }

                val rpmRate=(140..280).random()
                rpm=min(redline+300,rpm+rpmRate)
                if(rpm>redline) {
                    rpm=max(3400,rpm-450)
                    damage=min(100,damage+1)
                }

                val baseSpeed=if(street)1.18 else 1.34
                val torqueFactor=(c.torque()/280.0).coerceIn(0.72,2.25)
                val ratioFactor=(currentRatio/1.60).coerceIn(0.48,2.25)
                val performanceBoost=(sqrt(powerFactor)*torqueFactor*ratioFactor/gearFactor)*0.55
                val gripFactor=(c.handling()/100.0)*(1.0-tempGripPenalty-pressurePenalty).coerceIn(0.65,1.0)
                val driveFactor=if(gear==1)driveLaunch else when(c.drivetrain()){"AWD"->1.04;"RWD"->1.00;else->0.98}
                val distanceGain=(baseSpeed + performanceBoost*gripFactor*driveFactor*tuneFactor*damageFactor) * traction.coerceAtLeast(0.72) * suspensionFactor
                raceProgress+=distanceGain
                opponent+=if(street)1.12 else 1.31

                tyreTemp=min(120.0,tyreTemp + if(street)0.65 else 0.45)
                if(gear==1 && wheelspin>0.35) tyreTemp=min(120.0,tyreTemp+0.35)

                if(street && Random.nextInt(100)<5){
                    val hit=Random.nextInt(2,7)
                    raceProgress=max(0.0,raceProgress-hit*0.5)
                    damage=min(100,damage+hit)
                    statusMessage(rv,"💥 TRAFFIC HIT! +$hit% DAMAGE")
                }
                if(street && Random.nextInt(100)<2){
                    damage=min(100,damage+8)
                    raceProgress=max(0.0,raceProgress-4.0)
                    statusMessage(rv,"🚧 HARD CRASH! RECOVERING")
                }

                rv.update(raceProgress,opponent,rpm,gear,nitro>0,damage,
                    "${c.drivetrain()} • ${tyreTemp.toInt()}°C • GRIP ${(c.handling()*(1.0-tempGripPenalty)).toInt()}")

                if(raceProgress>=100 || opponent>=100){
                    finishRace(street,raceProgress>=opponent,TextView(this))
                    return
                }
                h.postDelayed(this,220)
            }
        }
        h.post(loop)
    }

    private fun statusMessage(rv:RaceView,msg:String){
        rv.update(raceProgress,opponent,rpm,gear,nitro>0,damage,msg)
    }

    private fun shiftVisual() {
        val c=cars[raceCar]
        val redline=c.redline()
        val target=when(gear){
            1->min(redline-350,launchRPM+900)
            2->redline-500
            3->redline-450
            4->redline-400
            5->redline-350
            else->redline-300
        }
        val ratios=c.gearRatios()
        val ratioBonus=ratios[(gear-1).coerceIn(0,5)]/1.5
        val diff=abs(rpm-target)
        val drivetrainBonus=when(c.drivetrain()){"AWD"->0.7;"RWD"->1.0;else->1.15}
        if(diff<=450){
            perfects++
            raceProgress+=(4.2*ratioBonus.coerceIn(0.70,1.55))/drivetrainBonus
            rpm=target-850
            tyreTemp=min(120.0,tyreTemp+1.2)
            statusMessage(raceView!!,"PERFECT SHIFT! 🔥")
        } else if(diff<=1100){
            raceProgress+=(2.0*ratioBonus.coerceIn(0.70,1.40))/drivetrainBonus
            rpm=target-1300
            statusMessage(raceView!!,"GOOD SHIFT")
        } else {
            raceProgress=max(0.0,raceProgress-1.0)
            damage=min(100,damage+1)
            statusMessage(raceView!!,"BAD SHIFT")
        }
        if(gear<6)gear++ else rpm=3400
    }

    private fun finishRace(street:Boolean,win:Boolean,status:TextView) {
        racing=false
        raceView?.stop()
        val c=cars[raceCar]
        var reward=if(win)(if(street)2200 else 1800)+perfects*350 else 400
        var repGain=if(win)20+(if(street)10 else 0) else 5
        if(raceEventIndex in 0..8 && win){
            val careerRewards=intArrayOf(2000,3500,5000,8000,12000,18000,28000,40000,75000)
            reward=careerRewards[raceEventIndex]
            if(raceEventIndex==3 || raceEventIndex==6 || raceEventIndex==8) bossWins++
            eventUnlocked=max(eventUnlocked,raceEventIndex+2)
        }
        if(raceEventIndex in 70..74 && win){
            championshipPoints+=10
            championshipRound++
            reward=6000+championshipRound*2500
        }
        if(raceEventIndex in 80..89 && win){crewRep+=20;reward+=2500}
        if(raceEventIndex in 90..95 && win){
            crewRep+=25
            if(rivalIndex<5) rivalIndex++
            reward+=5000
        }
        if(win){
            cash+=reward; totalCashEarned+=reward; rep+=repGain; wins++; perfectShiftTotal+=perfects
            eventUnlocked=min(9,max(eventUnlocked,raceEventIndex+2))
        } else { losses++ }
        raceEventIndex=-1
        save()
        if(testMode){
            testMode=false
            Toast.makeText(this,
                "🧪 TEST RUN: ${c.name} • 0–100 ${estimate0100(c)}s • ¼ ${estimateQuarter(c)}s",
                Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this,
                if(win)"🏆 WIN! +${money(reward)} +$repGain REP" else "💀 LOSS — better luck next run",
                Toast.LENGTH_LONG).show()
        }
        Handler(Looper.getMainLooper()).postDelayed({showGarage()},1500)
    }

    private fun startDrag(career:Boolean=false){raceScreen(false,career)}
    private fun startStreet(career:Boolean=false){raceScreen(true,career)}
}