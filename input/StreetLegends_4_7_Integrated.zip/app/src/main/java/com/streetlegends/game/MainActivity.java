package com.streetlegends.game;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.egl.EGLConfig;
import android.view.*;
import java.nio.*;
import java.util.*;

public class MainActivity extends Activity {
    GameSurface surface;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        surface = new GameSurface(this);
        setContentView(surface);
    }
    @Override protected void onPause(){ super.onPause(); surface.onPause(); }
    @Override protected void onResume(){ super.onResume(); surface.onResume(); }

    static class Save {
        final SharedPreferences p;
        Save(Context c){ p=c.getSharedPreferences("street_legends",0); }
        int cash(){ return p.getInt("cash",12000); }
        void cash(int v){p.edit().putInt("cash",Math.max(0,v)).apply();}
        int power(){return p.getInt("power",0);}
        int grip(){return p.getInt("grip",0);}
        int nitro(){return p.getInt("nitro",0);}
        int car(){return p.getInt("car",0);}
        int career(){return p.getInt("career",0);}
        int champ(){return p.getInt("champ",0);}
        int paint(){return p.getInt("paint",0);}
        int wheels(){return p.getInt("wheels",0);}
        int stance(){return p.getInt("stance",0);}
        void set(String k,int v){p.edit().putInt(k,v).apply();}
    }

    static class CarDef {
        String name; float top, accel, grip; int color;
        CarDef(String n,float t,float a,float g,int c){name=n;top=t;accel=a;grip=g;color=c;}
    }

    static final CarDef[] CARS = {
        new CarDef("Vortex S1", 245, 10.0f, 1.00f, Color.rgb(30,120,235)),
        new CarDef("Apex RS", 270, 10.8f, 1.03f, Color.rgb(235,55,45)),
        new CarDef("Nightfall GT", 295, 11.4f, 1.05f, Color.rgb(55,60,75)),
        new CarDef("Tempest XR", 315, 12.0f, 1.07f, Color.rgb(190,45,210)),
        new CarDef("Revenant 5.0", 335, 12.8f, 1.09f, Color.rgb(245,180,45)),
        new CarDef("Eclipse R", 350, 13.5f, 1.12f, Color.rgb(45,200,160)),
        new CarDef("Hammer V8", 365, 14.0f, 1.14f, Color.rgb(235,235,235)),
        new CarDef("Spectre X", 385, 14.8f, 1.18f, Color.rgb(145,145,155))
    };

    static class GameSurface extends android.widget.FrameLayout {
        final GLSurfaceView gl;
        final RaceRenderer renderer;
        final HudView overlay;

        GameSurface(Context c){
            super(c);
            setWillNotDraw(false);
            gl=new GLSurfaceView(c);
            gl.setEGLContextClientVersion(2);
            renderer=new RaceRenderer(c);
            gl.setRenderer(renderer);
            gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
            addView(gl,new android.widget.FrameLayout.LayoutParams(-1,-1));
            overlay=new HudView(c,renderer);
            addView(overlay,new android.widget.FrameLayout.LayoutParams(-1,-1));
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            renderer.touch(e);
            overlay.invalidate();
            return true;
        }
        @Override protected void onSizeChanged(int w,int h,int ow,int oh){ super.onSizeChanged(w,h,ow,oh); overlay.invalidate(); }
    }

    static class RaceRenderer implements GLSurfaceView.Renderer {
        final Context ctx; final Save save;
        final HudView hud;
        final float[] proj=new float[16], view=new float[16];
        final ArrayList<Particle> particles=new ArrayList<>();
        long last;
        int screen=0; // 0 garage, 1 street, 2 drag, 3 upgrades, 4 career
        int selected;
        float speed=0, distance=0, rpm=1100, steer=0;
        int gear=1; boolean throttle, brake, handbrake, nitro;
        float raceTime=0, countdown=3.2f, opponent=0, playerProgress=0;
        int position=1;
        float camYaw=0;
        int graphics=2;
        final float[] touchX=new float[10], touchY=new float[10];
        final boolean[] down=new boolean[10];

        RaceRenderer(Context c){ctx=c;save=new Save(c);selected=save.car();hud=new HudView(ctx,this); last=System.nanoTime();}

        @Override public void onSurfaceCreated(GL10 gl, EGLConfig cfg){
            GLES20.glClearColor(0.035f,0.045f,0.06f,1);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            
        }
        @Override public void onSurfaceChanged(GL10 gl,int w,int h){
            GLES20.glViewport(0,0,w,h);
            
        }
        @Override public void onDrawFrame(GL10 gl){
            long now=System.nanoTime(); float dt=Math.min(.05f,(now-last)/1e9f); last=now;
            update(dt);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
            if(screen==0 || screen==3 || screen==4) drawGarage(gl);
            else drawRace(gl);
        }

        void update(float dt){
            if(screen==1 || screen==2){
                if(countdown>0) countdown-=dt;
                else {
                    raceTime+=dt;
                    float target=CARS[selected].top + save.power()*7;
                    float a=CARS[selected].accel + save.power()*.45f;
                    if(throttle) speed += a*dt*8;
                    else speed -= 5*dt;
                    if(brake) speed -= 16*dt;
                    if(handbrake) speed -= 7*dt;
                    if(nitro) {speed += 28*dt; spawnSmoke(2);}
                    speed=Math.max(0,Math.min(target,speed));
                    rpm=900 + (speed/Math.max(1,target))*6200 + ((gear-1)*250);
                    if(rpm>6950 && throttle) {rpm=2800; gear=Math.min(6,gear+1);}
                    if(rpm<1700 && gear>1 && !throttle) gear--;
                    distance += speed*dt/3.6f;
                    playerProgress=Math.min(1, distance/(screen==2?402f:1600f));
                    opponent=Math.min(1, opponent + dt*(0.075f + selected*.004f));
                    if(playerProgress>=1 || opponent>=1){
                        if(playerProgress>=opponent){position=1; save.cash(save.cash()+1200+selected*300); save.set("champ",save.champ()+3);}
                        else {position=2; save.cash(save.cash()+350); save.set("champ",save.champ()+1);}
                        screen=4;
                    }
                    if(Math.abs(steer)>.15f) spawnSmoke(1);
                }
            }
            for(Iterator<Particle> it=particles.iterator();it.hasNext();){
                Particle p=it.next(); p.life-=dt; p.x+=p.vx*dt; p.y+=p.vy*dt; p.z+=p.vz*dt;
                if(p.life<=0) it.remove();
            }
        }

        void drawGarage(GL10 gl){
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            // A simple 3D-ish showroom rendered by the HUD layer; keep GL clear here.
            GLES20.glClearColor(.025f,.03f,.045f,1);
        }
        void drawRace(GL10 gl){
            // Procedural road/city is rendered by Hud's Canvas layer with depth-style perspective.
            // GL remains the stable accelerated surface for the Android device.
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        }

        void spawnSmoke(int n){
            if(particles.size()>140) return;
            for(int i=0;i<n;i++) particles.add(new Particle((float)(Math.random()-.5)*.5f,.1f,-2f,(float)(Math.random()-.5)*.5f,.4f,(float)(Math.random()-.5)*.2f));
        }

        void start(int mode){
            screen=mode; speed=0; distance=0; raceTime=0; countdown=3.2f; opponent=0; playerProgress=0; position=1; gear=1; rpm=1100;
        }
        void buy(int type){
            int level = type==0?save.power():type==1?save.grip():save.nitro():type==2?save.wheels():save.stance();
            int cost=900+(level*700);
            if(save.cash()<cost) return;
            save.cash(save.cash()-cost);
            if(type==0) save.set("power",save.power()+1);
            if(type==1) save.set("grip",save.grip()+1);
            if(type==2) save.set("nitro",save.nitro()+1);
            if(type==3) save.set("wheels",save.wheels()+1);
            if(type==4) save.set("stance",save.stance()+1);
        }
        void touch(MotionEvent e){
            float x=e.getX(), y=e.getY(); int action=e.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN){
                int idx=e.getActionIndex(); touchX[idx]=x; touchY[idx]=y; down[idx]=true; hud.tap(x,y);
            } else if(action==MotionEvent.ACTION_MOVE){
                for(int i=0;i<e.getPointerCount();i++){touchX[e.getPointerId(i)]=e.getX(i);touchY[e.getPointerId(i)]=e.getY(i);}
                hud.controls();
            } else if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL){
                int idx=e.getActionIndex(); down[idx]=false; hud.controls();
            }
        }
        void shift(int d){ if(screen==1||screen==2) gear=Math.max(1,Math.min(6,gear+d)); }
    }

    static class Particle {
        float x,y,z,vx,vy,vz,life=1;
        Particle(float X,float Y,float Z,float a,float b,float c){x=X;y=Y;z=Z;vx=a;vy=b;vz=c;}
    }

    static class HudView extends View {
        final RaceRenderer r;
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF rr=new RectF();
        int w,h;
        HudView(Context c,RaceRenderer rr){super(c);r=rr;p.setTypeface(Typeface.create("sans",Typeface.BOLD));setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void box(Canvas c,float l,float t,float rt,float b,int color,float rad){
            p.setColor(color);p.setStyle(Paint.Style.FILL);rr.set(l,t,rt,b);c.drawRoundRect(rr,rad,rad,p);
        }
        void text(Canvas c,String s,float x,float y,float size,int color){
            p.setColor(color);p.setTextSize(size);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);
        }
        void center(Canvas c,String s,float y,float size,int color){
            p.setTextSize(size);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawText(s,(w-p.measureText(s))/2f,y,p);
        }
        @Override protected void onDraw(Canvas c){
            w=getWidth();h=getHeight();
            if(r.screen==0) garage(c);
            else if(r.screen==3) upgrades(c);
            else if(r.screen==4) career(c);
            else race(c);
            postInvalidateDelayed(33);
        }
        void top(Canvas c,String title,String sub){
            p.setShader(new LinearGradient(0,0,w,0,Color.rgb(12,16,25),Color.rgb(28,34,48),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,92,p);p.setShader(null);
            text(c,"STREET LEGENDS",28,38,25,Color.WHITE);
            text(c,title,28,72,18,Color.LTGRAY);
            text(c,sub,w-230,38,16,Color.WHITE);
        }
        void garage(Canvas c){
            top(c,"GARAGE","$"+r.save.cash());
            // showroom floor
            p.setColor(Color.rgb(25,28,35));c.drawRect(0,h*.25f,w,h,p);
            p.setColor(Color.rgb(55,58,66));c.drawOval(new RectF(w*.25f,h*.35f,w*.75f,h*.92f),p);
            drawCar(c,w*.5f,h*.55f,1.0f,r.CARS[r.selected].color);
            center(c,r.CARS[r.selected].name,h*.86f,28,Color.WHITE);
            text(c,"POWER "+(100+r.save.power()*12)+" HP",w*.5f-190,h*.91f,16,Color.LTGRAY);
            text(c,"GRIP "+(100+r.save.grip()*6)+"%",w*.5f-45,h*.91f,16,Color.LTGRAY);
            text(c,"NITRO "+(1+r.save.nitro())+"x",w*.5f+80,h*.91f,16,Color.LTGRAY);
            box(c,18,h*.68f,w*.30f,h*.82f,0xcc10151f,22);centerText(c,"STREET RACE",w*.16f,h*.76f,18);
            box(c,w*.34f,h*.68f,w*.64f,h*.82f,0xcc10151f,22);centerText(c,"DRAG",w*.49f,h*.76f,18);
            box(c,w*.68f,h*.68f,w-18,h*.82f,0xcc10151f,22);centerText(c,"UPGRADES",w*.84f,h*.76f,18);
            text(c,"Tap a car card to select",24,h*.30f,14,Color.LTGRAY);
            float cw=w/Math.min(4,r.CARS.length);
            for(int i=0;i<r.CARS.length;i++){
                int row=i/4,col=i%4; float x=col*cw+10,y=h*.16f+row*70;
                box(c,x,y,x+cw-20,y+58,i==r.selected?0xdd394b63:0xaa151b26,14);
                text(c,r.CARS[i].name,x+12,y+34,14,Color.WHITE);
            }
        }
        void upgrades(Canvas c){
            top(c,"UPGRADES","$"+r.save.cash());
            String[] n={"ENGINE / TURBO","TYRES / GRIP","NITRO SYSTEM","WHEELS","STANCE"};
            int[] lv={r.save.power(),r.save.grip(),r.save.nitro(),r.save.wheels(),r.save.stance()};
            for(int i=0;i<5;i++){
                float y=h*.16f+i*h*.14f;
                box(c,25,y,w-25,y+h*.105f,0xdd141a24,18);
                text(c,n[i],45,y+30,19,Color.WHITE);
                text(c,"LEVEL "+lv[i],45,y+56,14,Color.LTGRAY);
                int cost=900+lv[i]*700;
                box(c,w-190,y+14,w-40,y+65,0xdd263247,15);
                text(c,"BUY $"+cost,w-172,y+46,15,Color.WHITE);
            }
            box(c,25,h*.89f,190,h*.97f,0xdd141a24,16);text(c,"BACK",72,h*.942f,17,Color.WHITE);
        }
        void career(Canvas c){
            top(c,"CAREER / RESULTS","$"+r.save.cash());
            center(c,r.position==1?"RACE WON":"RACE FINISHED",h*.27f,38,r.position==1?Color.WHITE:Color.LTGRAY);
            center(c,"CHAMPIONSHIP POINTS  "+r.save.champ(),h*.36f,20,Color.LTGRAY);
            String tier=r.save.career()<1?"ROOKIE":r.save.career()<2?"STREET":r.save.career()<3?"PRO":r.save.career()<4?"ELITE":"UNDERGROUND";
            center(c,tier,h*.45f,28,Color.WHITE);
            box(c,w*.18f,h*.57f,w*.82f,h*.70f,0xdd151c28,20);
            center(c,"BOSS RACE AVAILABLE",h*.63f,20,Color.WHITE);
            center(c,"Tap CONTINUE to return to the garage",h*.68f,14,Color.LTGRAY);
            box(c,w*.35f,h*.77f,w*.65f,h*.88f,0xdd263247,18);
            center(c,"CONTINUE",h*.835f,19,Color.WHITE);
        }
        void race(Canvas c){
            // Perspective road and city.
            p.setColor(Color.rgb(9,12,18));c.drawRect(0,0,w,h,p);
            p.setColor(Color.rgb(35,43,50));Path road=new Path();road.moveTo(w*.40f,h*.28f);road.lineTo(w*.60f,h*.28f);road.lineTo(w*.95f,h);road.lineTo(w*.05f,h);road.close();c.drawPath(road,p);
            p.setColor(Color.rgb(70,73,78));c.drawRect(0,h*.28f,w*.40f,h,p);c.drawRect(w*.60f,h*.28f,w,h,p);
            // lane markers
            p.setColor(Color.WHITE);
            for(int i=0;i<7;i++){float yy=h*.35f+i*h*.11f;float ww=4+i*3;c.drawRect(w*.5f-ww,yy,w*.5f+ww,yy+18+i*2,p);}
            // city blocks
            p.setColor(Color.rgb(22,28,36));
            for(int i=0;i<8;i++){float x=(i%4)*w*.25f;float bh=50+(i%3)*35;c.drawRect(x,h*.28f-bh,x+w*.19f,h*.28f,p);}
            // player car
            drawCar(c,w*.5f,h*.73f,1.0f,r.CARS[r.selected].color);
            // top HUD
            box(c,18,18,250,80,0xcc0b1018,18);text(c,"POS "+r.position+"/4",34,50,20,Color.WHITE);text(c,"GEAR "+r.gear,140,50,20,Color.WHITE);
            text(c,String.format(Locale.US,"%03d KM/H",(int)r.speed),18,112,25,Color.WHITE);
            // tachometer
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(7);p.setColor(Color.LTGRAY);c.drawArc(new RectF(w-220,20,w-40,200),200,140,false,p);p.setStyle(Paint.Style.FILL);
            text(c,"RPM",w-153,75,14,Color.LTGRAY);text(c,""+(int)r.rpm,w-145,112,24,Color.WHITE);
            if(r.countdown>0)center(c,r.countdown>2?"3":r.countdown>1?"2":r.countdown>.3f?"1":"GO!",h*.25f,54,Color.WHITE);
            // progress
            box(c,w*.25f,15,w*.75f,30,0xaa111722,8);box(c,w*.25f,15,w*.25f+(w*.5f*r.playerProgress),30,Color.WHITE,8);
            // controls
            button(c,20,h*.72f,145,h*.88f,"STEER ◀");button(c,155,h*.72f,280,h*.88f,"STEER ▶");
            button(c,w*.64f,h*.66f,w*.82f,h*.82f,"THROTTLE");button(c,w*.64f,h*.84f,w*.82f,h*.97f,"BRAKE");
            button(c,w*.40f,h*.80f,w*.60f,h*.94f,"HANDBRAKE");
            button(c,w*.84f,h*.58f,w*.98f,h*.76f,"NITRO");
            button(c,w*.84f,18,w*.92f,78,"- G");button(c,w*.93f,18,w*.99f,78,"+ G");
        }
        void button(Canvas c,float l,float t,float rt,float b,String s){box(c,l,t,rt,b,0xaa111721,18);p.setTextSize(15);p.setColor(Color.WHITE);c.drawText(s,(l+rt-p.measureText(s))/2,(t+b)/2+6,p);}
        void centerText(Canvas c,String s,float x,float y,float size){p.setTextSize(size);p.setColor(Color.WHITE);c.drawText(s,x-p.measureText(s)/2,y,p);}
        void drawCar(Canvas c,float x,float y,float scale,int color){
            p.setColor(color);rr.set(x-110*scale,y-55*scale,x+110*scale,y+55*scale);c.drawRoundRect(rr,28,28,p);
            p.setColor(Color.rgb(25,30,38));Path cab=new Path();cab.moveTo(x-65,y-55);cab.lineTo(x-25,y-100);cab.lineTo(x+48,y-100);cab.lineTo(x+75,y-55);cab.close();c.drawPath(cab,p);
            p.setColor(Color.rgb(180,220,245));c.drawRoundRect(new RectF(x-35,y-88,x+42,y-58),10,10,p);
            p.setColor(Color.BLACK);c.drawCircle(x-72,y+50,25,p);c.drawCircle(x+72,y+50,25,p);
            p.setColor(Color.LTGRAY);c.drawCircle(x-72,y+50,11,p);c.drawCircle(x+72,y+50,11,p);
            p.setColor(Color.WHITE);c.drawRoundRect(new RectF(x-103,y-25,x-75,y-5),7,7,p);
            p.setColor(Color.RED);c.drawRoundRect(new RectF(x+75,y-25,x+103,y-5),7,7,p);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN || e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN){
                int i=e.getActionIndex();r.touchX[i]=e.getX(i);r.touchY[i]=e.getY(i);r.down[i]=true;tap(e.getX(i),e.getY(i));controls();invalidate();return true;
            }
            if(e.getActionMasked()==MotionEvent.ACTION_MOVE){for(int i=0;i<e.getPointerCount();i++){int id=e.getPointerId(i);r.touchX[id]=e.getX(i);r.touchY[id]=e.getY(i);}controls();invalidate();return true;}
            if(e.getActionMasked()==MotionEvent.ACTION_UP || e.getActionMasked()==MotionEvent.ACTION_POINTER_UP || e.getActionMasked()==MotionEvent.ACTION_CANCEL){
                r.down[e.getActionIndex()]=false;controls();invalidate();return true;
            }
            return true;
        }
        void tap(float x,float y){
            if(r.screen==0){
                if(y>h*.68f){if(x<w*.34f)r.start(1);else if(x<w*.67f)r.start(2);else r.screen=3;}
                else if(y>h*.14f&&y<h*.55f){int col=(int)(x/(w/4));int row=(int)((y-h*.14f)/70);int i=row*4+col;if(i>=0&&i<r.CARS.length){r.selected=i;r.save.set("car",i);}}
            } else if(r.screen==3){
                if(y<h*.14f){r.screen=0;return;}
                if(y>h*.16f&&y<h*.86f){int row=(int)((y-h*.16f)/(h*.14f));r.buy(Math.max(0,Math.min(4,row)));}
            } else if(r.screen==4){if(y>h*.72f)r.screen=0;}
            else {if(y<100&&x>w*.92f)r.shift(1); if(y<100&&x>w*.84f&&x<=w*.92f)r.shift(-1);}
        }
        void controls(){
            if(r.screen!=1&&r.screen!=2)return;
            r.steer=0;r.throttle=false;r.brake=false;r.handbrake=false;r.nitro=false;
            for(int i=0;i<r.down.length;i++)if(r.down[i]){
                float x=r.touchX[i],y=r.touchY[i];
                if(y>h*.70f&&x<w*.18f)r.steer=-1;
                if(y>h*.70f&&x>=w*.18f&&x<w*.36f)r.steer=1;
                if(y>h*.62f&&x>=w*.62f&&x<w*.84f)r.throttle=true;
                if(y>h*.80f&&x>=w*.62f&&x<w*.84f)r.brake=true;
                if(y>h*.78f&&x>=w*.36f&&x<w*.62f)r.handbrake=true;
                if(y>h*.55f&&x>w*.84f)r.nitro=true;
            }
        }
    }
}
