# Street Legends 4.7 — Integrated Racing Build

This build applies the racing-layer work directly into one Android app:
- real OpenGL ES 3D procedural car and city/road scene
- garage/showroom
- paint, wheels, stance and performance upgrades
- drag and street race modes
- steering, throttle, brake, handbrake, nitrous
- manual up/down shifting
- RPM tachometer and speed/gear HUD
- launch countdown and race position
- AI opponents and traffic
- tyre smoke, nitrous and brake-light effects
- career tiers, boss races and championship points
- persistent cash, upgrades, car selection and progression
- graphics presets
- original fictional cars/assets only

Build with AndroidForge using this ZIP.
