## 4.7 implemented
All core racing/garage/progression systems are wired into the same app project.

## Next visual target
Replace the procedural cars with authored 3D meshes/materials and add higher-detail environments while keeping the same gameplay APIs.
