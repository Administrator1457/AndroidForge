
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.streetlegends"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.streetlegends"
        minSdk = 26
        targetSdk = 34
        versionCode = 33
        versionName = "3.3.0"
    }
}
