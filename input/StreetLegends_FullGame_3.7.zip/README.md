# Street Legends — Full Game Edition 3.0

Original Android racing game project. This is the consolidated full-game build rather than a feature-by-feature prototype.

## Included systems
- 20 fictional cars across T1–T5
- Persistent garage, dealership and car collection
- Engine / turbo / ECU / gearbox / tyres / exhaust upgrades
- I4 / V6 / V8 identity, displacement, torque and tier redlines
- FWD / RWD / AWD behaviour
- 6-speed gear ratios and shift timing
- Launch RPM, traction control, wheelspin and launch grip
- Tyre temperature, tyre pressure and suspension tuning
- Boost and final-drive tuning
- Test & Tune race run
- Estimated 0–100 and quarter-mile performance
- Drag racing and street racing
- Traffic, crashes, damage, fuel and tyre heat
- Career ladder with progressive events and bosses
- Crew reputation and rival ladder
- Five-round championship mode
- Parts tokens, crates and parts rank
- Daily challenges with date-based reset
- Profile statistics and achievements
- Paint, wheels, stance and street package customization
- Service bay for repairs and refuelling
- Developer/test menu
- Persistent save data
- Custom drawn race scene and touch controls

## Build
Open the project in Android Studio and build the `app` module.
Package: `com.streetlegends`
Min SDK: 26
Target SDK: 35
Version: 3.4.0

## Important
The game uses original fictional car names and original drawn visuals. It does not include proprietary CSR2 or Burnout Masters assets.


Build fix 3.4: Java and Kotlin compilation targets are explicitly aligned to JVM 17 for AndroidForge/GitHub Actions.
